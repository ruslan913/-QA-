import requests
from typing import Dict, Any

class ApiClient:
    BASE_URL = "https://qa-internship.avito.com"

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "Content-Type": "application/json",
            "Accept": "application/json"
        })

    def create_item_v1(self, payload: Dict[str, Any]) -> requests.Response:
        """POST /api/1/item — создать объявление"""
        # Автоматически добавляем likes, если его нет
        if "likes" not in payload:
            payload["likes"] = 0
        return self.session.post(f"{self.BASE_URL}/api/1/item", json=payload)

    def get_item_v1(self, item_id: str) -> requests.Response:
        """GET /api/1/item/{id}"""
        return self.session.get(f"{self.BASE_URL}/api/1/item/{item_id}")

    def get_seller_items_v1(self, seller_id: int) -> requests.Response:
        """GET /api/1/{sellerID}/item"""
        return self.session.get(f"{self.BASE_URL}/api/1/{seller_id}/item")

    def get_statistic_v1(self, item_id: str) -> requests.Response:
        """GET /api/1/statistic/{id}"""
        return self.session.get(f"{self.BASE_URL}/api/1/statistic/{item_id}")

    def get_item_v2(self, item_id: str) -> requests.Response:
        """GET /api/2/item/{id}"""
        return self.session.get(f"{self.BASE_URL}/api/2/item/{item_id}")

    def delete_item_v2(self, item_id: str) -> requests.Response:
        """DELETE /api/2/item/{id}"""
        return self.session.delete(f"{self.BASE_URL}/api/2/item/{item_id}")

    def get_statistic_v2(self, item_id: str) -> requests.Response:
        """GET /api/2/statistic/{id}"""
        return self.session.get(f"{self.BASE_URL}/api/2/statistic/{item_id}")