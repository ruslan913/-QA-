import allure

@allure.feature("Удаление объявления")
class TestDeleteItem:

    @allure.title("Удаление существующего объявления")
    def test_delete_existing_item(self, api_client, unique_seller_id):
        # Создаём
        create_payload = {
            "sellerId": unique_seller_id,
            "name": "Кот на удаление",
            "price": 5000
        }
        create_response = api_client.create_item_v1(create_payload)
        assert create_response.status_code == 200
        item_id = create_response.json().get("id")

        # Удаляем
        delete_response = api_client.delete_item_v2(item_id)
        assert delete_response.status_code == 200

        # Проверяем, что удалено
        get_response = api_client.get_item_v1(item_id)
        assert get_response.status_code == 404

    @allure.title("Удаление по несуществующему ID")
    def test_delete_nonexistent_item(self, api_client):
        response = api_client.delete_item_v2("999999999999")
        assert response.status_code == 404