import allure

@allure.feature("E2E сценарии")
class TestE2E:

    @allure.title("Полный жизненный цикл")
    def test_full_lifecycle(self, api_client, unique_seller_id):
        # 1. CREATE
        create_payload = {
            "sellerId": unique_seller_id,
            "name": "E2E Кот",
            "price": 10000
        }
        create_response = api_client.create_item_v1(create_payload)
        assert create_response.status_code == 200
        item_id = create_response.json().get("id")

        # 2. GET by ID
        get_response = api_client.get_item_v1(item_id)
        assert get_response.status_code == 200

        # 3. GET by seller ID
        seller_items_response = api_client.get_seller_items_v1(unique_seller_id)
        assert seller_items_response.status_code == 200

        # 4. GET statistic
        stat_response = api_client.get_statistic_v1(item_id)
        assert stat_response.status_code == 200

        # 5. DELETE
        delete_response = api_client.delete_item_v2(item_id)
        assert delete_response.status_code == 200

        # 6. Verify deletion
        get_after_delete = api_client.get_item_v1(item_id)
        assert get_after_delete.status_code == 404