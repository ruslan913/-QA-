import allure
import pytest

@allure.feature("Создание объявления")
class TestCreateItem:

    @allure.title("Создание объявления с минимальными полями")
    def test_create_item_minimal(self, api_client, unique_seller_id):
        payload = {
            "sellerId": unique_seller_id,
            "name": "Котёнок",
            "price": 1000
        }
        response = api_client.create_item_v1(payload)
        assert response.status_code == 200
        data = response.json()
        assert "id" in data
        assert len(data["id"]) > 0

    @allure.title("Создание объявления с ценой 0 (баг)")
    def test_create_item_zero_price(self, api_client, unique_seller_id):
        payload = {
            "sellerId": unique_seller_id,
            "name": "Бесплатный кот",
            "price": 0
        }
        response = api_client.create_item_v1(payload)
        # Ожидается 400, но API возвращает 200 — это баг
        if response.status_code == 200:
            pytest.xfail("Баг: цена 0 принимается как валидная")
        assert response.status_code == 400

    @allure.title("Создание без sellerId")
    def test_create_item_missing_seller_id(self, api_client):
        payload = {
            "name": "Котёнок",
            "price": 1000
        }
        response = api_client.create_item_v1(payload)
        assert response.status_code == 400