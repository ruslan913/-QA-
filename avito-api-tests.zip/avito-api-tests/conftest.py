import pytest
import random
from utils.api_client import ApiClient

def pytest_terminal_summary(terminalreporter, exitstatus, config):
    terminalreporter.section("ИТОГИ", sep="-", blue=True)
    terminalreporter.write_line("Пройдено: {}".format(len(terminalreporter.stats.get('passed', []))))
    terminalreporter.write_line("Провалено: {}".format(len(terminalreporter.stats.get('failed', []))))
    terminalreporter.write_line("Пропущено: {}".format(len(terminalreporter.stats.get('skipped', []))))
    terminalreporter.write_line("Ожидаемые баги (xfail): {}".format(len(terminalreporter.stats.get('xfailed', []))))

@pytest.fixture(scope="session")
def api_client():
    return ApiClient()

@pytest.fixture
def unique_seller_id():
    return random.randint(111111, 999999)

@pytest.fixture
def created_item(api_client, unique_seller_id):
    payload = {
        "sellerId": unique_seller_id,
        "name": "Тестовый котёнок",
        "price": 5000,
        "likes": 0
    }
    response = api_client.create_item_v1(payload)
    assert response.status_code == 200, f"Ошибка создания: {response.text}"
    item_id = response.json().get("id")
    yield item_id, unique_seller_id
    api_client.delete_item_v2(item_id)